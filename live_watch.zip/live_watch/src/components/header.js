import React from "react";
class Header  extends  React.Component
{
    render()
    {
        return(

            <header>
                    holis
            </header>
        )
    }
}
export default Header;